/* Appended upon by: Eland Anthony
CS300 with Dr. Anderson */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdbool.h>
#include "stats_record_formats.h"
#include "queue_ids.h" 

void parseStdin();
void msgsndPitch(int playerNum, char atBatResults[]);
int msgrcvStats();


#ifndef darwin
size_t                  /* O - Length of string */
strlcpy(char       *dst,        /* O - Destination string */
        const char *src,      /* I - Source string */
        size_t      size)     /* I - Size of destination string buffer */
{
    size_t    srclen;         /* Length of source string */


    /*
     * Figure out how much room is needed...
     */

    size --;

    srclen = strlen(src);

    /*
     * Copy the appropriate amount...
     */

    if (srclen > size)
        srclen = size;

    memcpy(dst, src, srclen);
    dst[srclen] = '\0';

    return (srclen);
}

#endif

//pase stdin for end of pitch signals. store each pitch result string and send to msgsnd function to be send to my java classes
void parseStdin()  {

    int playerNum = 0;
    bool endOfPitch = true;
	static char newAtBat[16] = "W O 1 2 3 H P S";
    char stdin_[2] = " ";
    char pitchResults[MAX_PITCHES_RECORDED_ARY_LEN] = "";
	fscanf(stdin, "%s", stdin_);
	while (strcmp(stdin_, "-1") != 0)  {
		if (endOfPitch) {
			playerNum = atoi(stdin_);
			endOfPitch = false;
		}
		else  {
			strncat(pitchResults, &stdin_[0], 1);
			if(strchr(newAtBat, stdin_[0])!=NULL) {
				msgsndPitch(playerNum, pitchResults);
				strcpy(pitchResults, "");
				endOfPitch = true;
			}
		}
		fscanf(stdin, "%s", stdin_);
	}
	strcat(pitchResults," ");
	msgsndPitch(-1, pitchResults);
    return;
}

//send at bat result message using Dr. Anderson pre defined implementation
void msgsndPitch(int playerNum, char atBatResults[])  {

    int msqid;
    int msgflg = IPC_CREAT | 0666;
    key_t key;
    atbat_buf sbuf;
    size_t buf_length;
    key = ftok(CRIMSON_ID,QUEUE_NUMBER);

    if ((msqid = msgget(key, msgflg)) < 0) {
        int errnum = errno;
        fprintf(stderr, "Value of errno: %d\n", errno);
        perror("(msgget)");
        fprintf(stderr, "Error msgget: %s\n", strerror( errnum ));
    }
    else {
    //fprintf(stderr, "\nmsgget: msgget succeeded: msgqid = %d\n", msqid);
    }

    // We'll send message type 1
    sbuf.mtype = 1;
    sbuf.player_id=playerNum;//player_id is -1 when game is over
    memset(sbuf.pitch_results,'\0',MAX_PITCHES_RECORDED_ARY_LEN);
    strlcpy(sbuf.pitch_results,atBatResults,MAX_PITCHES_RECORDED);
    buf_length = strlen(sbuf.pitch_results) + sizeof(int)+1;//struct size without    
    // Send a message.
    if((msgsnd(msqid, &sbuf, buf_length, IPC_NOWAIT)) < 0) {
        int errnum = errno;
        fprintf(stderr,"%d, %ld, %d, %d\n", msqid, sbuf.mtype, sbuf.player_id, (int)buf_length);
        perror("(msgsnd)");
        fprintf(stderr, "Error sending msg: %s\n", strerror( errnum ));
    }
    else {
    fprintf(stderr,"msgsnd-atbat: player id\"#%d\" Sent (%d bytes)\n", sbuf.player_id,(int)buf_length);
    }
}

//recieve message using Dr. Anderson pre defined implementation
int msgrcvStats() {

	int msqid;
    int msgflg = IPC_CREAT | 0666;
    key_t key;
    msqid = msgget(key, 0666 | IPC_CREAT);
    stats_buf rbuf;
    size_t buf_length;

    key = ftok(CRIMSON_ID,QUEUE_NUMBER);
    if ((msqid = msgget(key, msgflg)) < 0) {
        int errnum = errno;
        fprintf(stderr, "Value of errno: %d\n", errno);
        perror("(msgget)");
        fprintf(stderr, "Error msgget: %s\n", strerror( errnum ));
    }
    else {
        //fprintf(stderr, "\nmsgget: msgget succeeded: msgqid = %d\n", msqid);
    }
    // msgrcv to receive message
    int ret;
    do {
      ret = msgrcv(msqid, &rbuf, sizeof(stats_buf), 2, 0);//receive type 2 message
      int errnum = errno;
      if (ret < 0 && errno !=EINTR){
        fprintf(stderr, "Value of errno: %d\n", errno);
        perror("Error printed by perror");
        fprintf(stderr, "Error receiving msg: %s\n", strerror( errnum ));
      }
    } while (((ret < 0 ) && (errno == 4)));
    fprintf(stderr,"msgrcv error return code --%d:$d--",ret);
    if (rbuf.game_avg == -1) return rbuf.count;
    fprintf(stderr,"msgrcv-stats: msg type-%ld, Player stats %d of %d for %s(#%d) strikeouts=%d, walks=%d, singles=%d, doubles=%d, triples=%d, home runs=%d, game avg=%lf overall avg=%lf ret/bytes rcv'd=%d\n", rbuf.mtype, rbuf.index,rbuf.count,rbuf.player_name,rbuf.player_id, rbuf.strike_outs,  rbuf.walks,  rbuf.singles,  rbuf.doubles,  rbuf.triples,  rbuf.home_runs,  rbuf.game_avg, rbuf.overall_avg,ret);
    printf("%s(#%d)\t \t%d\t%d \t%d \t%d \t%d \t  %d \t\t%0.3f %0.3f\n\n", rbuf.player_name, rbuf.player_id, rbuf.singles, rbuf.doubles, rbuf.triples, rbuf.home_runs, rbuf.walks, rbuf.strike_outs, rbuf.game_avg, rbuf.overall_avg);        
    return rbuf.count;       
}

//verify args and display report headers. use rbuf.count to keep track of messages
int main(int argc, char**argv) {
	int msqid;
    key_t key;
    key = ftok(CRIMSON_ID,QUEUE_NUMBER);
    int msgflg = IPC_CREAT | 0666;
    msqid = msgget(key, 0666 | IPC_CREAT);
    atbat_buf sbuf;
    stats_buf rbuf;
    size_t buf_length;
    char currentGame [30] = "";

	if (argc != 2) {
        fprintf(stderr, "Invalid arguments: Usage: ./gameplaytracker <Game Name> <Stdin> \n");
		return 0;
	}
    strcpy(currentGame, argv[1]);

	parseStdin();
    
    printf("\n");
    printf("%s: Game Stats\n", currentGame);
    printf("Player \t\t\t\tSingles Doubles Triples HomeRuns Walks   Strike-outs Batting Average\n");
    printf("\t\t\t\t\t\t\t\t\t\t      Game  Overall");
    printf("\n");

    int msgCounter = msgrcvStats();
    while (msgCounter > 1) {
        msgrcvStats();
        msgCounter--;
    }
	return 0;
}
