package edu.cs300;
import java.io.*;
import java.util.Scanner;

/* Created By: Eland Anthony
CS300 with Dr. Anderson */

public class Computation {
    
    //declarations
    String name;
    int playerNumber;
    int atBats;
    int totalAtBats;
    int balls;
    int fouls;
    int strikes;
    int outs;
    int strikeOuts;
    int walks;
    int hitByPitch;
    int singles;
    int doubles;
    int triples;
    int homeRuns;
    int totalOuts;
    int totalStrikeOuts;
    int totalWalks;
    int totalHitByPitches;
    int totalSingles;
    int totalDoubles;
    int totalTriples;
    int totalHomeRuns;
    double battingAvg;
    double totalBattingAvg;

    //constructor/initialization
    public Computation() {
    this.atBats = 0;
    this.totalAtBats = 0;
    this.balls = 0;
    this.fouls = 0;
    this.strikes = 0;
    this.outs = 0;
    this.strikeOuts = 0;
    this.walks = 0;
    this.hitByPitch = 0;
    this.singles = 0;
    this.doubles = 0;
    this.triples = 0;
    this.homeRuns = 0;
    this.totalOuts = 0;
    this.totalStrikeOuts = 0;
    this.totalWalks = 0;
    this.totalHitByPitches = 0;
    this.totalSingles = 0;
    this.totalDoubles = 0;
    this.totalTriples = 0;
    this.totalHomeRuns = 0;
    this.battingAvg = 0.0;
    this.totalBattingAvg = 0.0;
    }

    //getters and setters 
    public int getAtBats(){
        return this.atBats;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPlayerNumber() {
        return this.playerNumber;
    }

    public void setPLayerNumber(int playerNumber) {
        this.playerNumber = playerNumber;
    }

    public int getWalks() {
        return this.walks;
    }

    public int getSingles() {
        return this.singles;
    }

    public int getDoubles() {
        return this.doubles;
    }

    public int getTriples() {
        return this.triples;
    }

    public int getStrikeouts() {
        return this.strikeOuts;
    }

    public int getHomeRuns() {
        return this.homeRuns;
    }

    public double getBattingAvg() {
        if (this.battingAvg == -1) return -1;
        double hits = ((double) (this.singles + this.doubles + this.triples + this.homeRuns));
        double denom = ((double) (this.atBats - (this.walks + this.hitByPitch)));
        if(hits ==0 || denom==0) return 0;
        else return hits/denom;
    }

    public double totalBattingAvg() {
        return this.totalBattingAvg;
    }

    public void setTotalBattingAvg(double totalBattingAvg) {
        this.totalBattingAvg = totalBattingAvg;
    }

    //Add previous lines (games) in text file to my vars of totals
    public void addPrevStatsToTotal(String currentLine[]) {
        this.totalAtBats += Integer.parseInt(currentLine[0]);
        this.totalOuts += Integer.parseInt(currentLine[1]);
        this.totalSingles += Integer.parseInt(currentLine[2]);
        this.totalDoubles += Integer.parseInt(currentLine[3]);
        this.totalTriples += Integer.parseInt(currentLine[4]);
        this.totalHomeRuns += Integer.parseInt(currentLine[5]);
        this.totalWalks += Integer.parseInt(currentLine[6]);
        this.totalStrikeOuts += Integer.parseInt(currentLine[7]);
        this.totalHitByPitches += Integer.parseInt(currentLine[8]);
        return;
    }

    //Add current game to vars of totals
    public void addGameToTotal() {
        this.totalAtBats += this.atBats;
        this.totalOuts += this.outs;
        this.totalSingles += this.singles;
        this.totalDoubles += this.doubles;
        this.totalTriples += this.triples;
        this.totalHomeRuns += this.homeRuns;
        this.totalStrikeOuts += this.strikeOuts;
        this.totalWalks += this.walks;
        this.totalHitByPitches += this.hitByPitch;
        return;
    }

    //Add existing player stats
    public void getCumulativeStats(int playerNumber) {
        String noAtBats[] = "0,0,0,0,0,0,0,0,0".split(",");
        try {
            this.playerNumber = playerNumber;
            File file = new File (playerNumber + ".txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String currentLine [] = scanner.nextLine().split(",");
                this.addPrevStatsToTotal(currentLine);
            }
            scanner.close();
        //If fail, player does not bat but is in playerstxt. Add a line of zeros.
        } catch (Exception ex) {
            this.addPrevStatsToTotal(noAtBats);
        }
        return;
    }
        
    //get numeric vals from chars in at bat char
    public void decodePitchResults(String atBatResults) {
        char currentBat;
        this.atBats++;
        for (int i = 0; i < atBatResults.length(); i++) {
            currentBat = atBatResults.charAt(i);
            if(currentBat == 'F') {
                this.fouls++;
            }
            else if(currentBat == 'B') {
                this.balls++;
            }
            else if(currentBat == 'K') {
                this.strikes++;
            }
            else if(currentBat == 'O') {
                this.outs++;
            }
            else if(currentBat == '1') {
                this.singles++;
            }
            else if(currentBat == '2') {
                this.doubles++;
            }
            else if(currentBat == '3') {
                this.triples++;
            }
            else if(currentBat == 'S') {
                this.strikeOuts++;
            }
            else if(currentBat == 'W') {
                this.walks++;
            }
            else if(currentBat == 'P') {
                this.hitByPitch++;
            }
            else if(currentBat == 'H') {
                this.homeRuns++;
            }
        }
        return;
    }

    //used to ensure those not batting have a batting avg of -1 and zeroes elsewhere
    public void setNoBatStats() {
        this.strikes = 0;
        this.balls = 0;
        this.fouls = 0;
        this.outs = 0;
        this.strikeOuts = 0;
        this.walks = 0;
        this.hitByPitch = 0;
        this.singles = 0;
        this.doubles = 0;
        this.triples = 0;
        this.homeRuns = 0;
        this.atBats = 0;
        this.totalBattingAvg = 0.0;
        this.battingAvg = -1;
    }

    //writing numeric vals to correct text file
    public void writeGame(int playerNumber) {
        try {
            File f = new File(playerNumber + ".txt");
            Boolean exists = f.exists();
            FileWriter file = new FileWriter(playerNumber + ".txt", true);
            BufferedWriter writer = new BufferedWriter(file);
            //if we are writing a new file we dont want a newline to begin
            if(exists) {
                writer.append("\n");
            }
            writer.append(this.atBats + "," + this.outs + "," + this.singles
            + "," + this.doubles + "," + this.triples + "," + this.homeRuns + "," + this.walks
            + "," + this.outs + "," + this.singles);
            writer.close();
        } catch (Exception ex) {
            System.err.println("FileNotFound exception triggered:"+ex);
        }
    } 

    public int getTotalOnBaseCount()  {
        return this.totalSingles + this.totalDoubles + this.totalTriples + this.totalHomeRuns + this.totalWalks + this.totalHitByPitches;
    }

    public double getTotalBattingAvg() {
        double totalHits = ((double) (this.totalSingles + this.totalDoubles + this.totalTriples + this.totalHomeRuns));
        double tDenom = ((double) (this.totalAtBats - (this.totalWalks + this.totalHitByPitches)));
        return totalHits / tDenom;
    }

    public void printReport(int playerNumber, String playerName)  {
        int totalOnBaseCount = this.getTotalOnBaseCount();
        double totalBattingAvg = this.getTotalBattingAvg();
        if (playerName == "Undefined Player")  {
            playerName = "(#" + Integer.toString(playerNumber) + ") Undefined Player";
        }
        System.out.printf("%s  \t %d \t   %d \t     %f", playerName, this.totalAtBats, totalOnBaseCount, totalBattingAvg);
        System.out.println();
        System.out.println();
    }

}
