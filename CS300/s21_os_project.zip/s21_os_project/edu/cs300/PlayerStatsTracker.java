package edu.cs300;

/* Appended upon by: Eland Anthony
CS300 with Dr. Anderson */

import java.util.concurrent.*;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

//use hash map to track players sent from c, use abq with computation object in order to send the computer output
public class PlayerStatsTracker {
    
        HashMap<Integer,ArrayBlockingQueue> playerMap;
        ArrayBlockingQueue<Computation> resultsOutputArray;
        int playerCount=0;

        //scan players file if it exists, store each player name and num, start thread for each player
        public PlayerStatsTracker() {
            this.playerMap = new HashMap<Integer, ArrayBlockingQueue>();
            this.resultsOutputArray = new ArrayBlockingQueue<Computation>(300);

            try {
                String playerName = "";
                int playerNum = 0;
                File f = new File ("players.txt");
                Scanner scanner = new Scanner(f);
                while(scanner.hasNextLine()) {
                    String currentLine[] = scanner.nextLine().split(",");
                    playerName = currentLine[0];
                    playerNum = Integer.parseInt(currentLine[1]);
                    this.playerMap.put(playerNum, new ArrayBlockingQueue<AtBatPitchResults>(10));
                    this.playerCount++;
                    new Worker(playerNum, this.playerMap.get(playerNum), this.resultsOutputArray, playerName).start();
                }
                scanner.close();
     
            } catch (Exception ex) {
               System.err.println("FileNotFoundException triggered:"+ex);
            }
        }

    public static void main(String[] args) throws FileNotFoundException {

        PlayerStatsTracker tracker= new PlayerStatsTracker();

        try {
            tracker.run();//Not a thread; run() is just convenient naming
        } catch   (InterruptedException e){
              System.err.println("InterruptedException:"+e);
        }
    }

    //read each message of pitch results from c, store player is and pitch result in hash map, if player undefined must start a thread for player regardless
    void run() throws InterruptedException {
        int currentPlayer = 0;
        while(currentPlayer!=-1) {
            AtBatPitchResults thisAtBat = new MessageJNI().readAtBatPitchResultsMsg();
            currentPlayer = thisAtBat.playerID;
            File f = new File(currentPlayer + ".txt");
            Boolean exists = f.exists();
            if(currentPlayer == -1) {
                for (int key : this.playerMap.keySet()) {
                    this.playerMap.get(key).put(thisAtBat);
                }
                break;
            }            
            else if(exists == false) {
                this.playerMap.put(currentPlayer, new ArrayBlockingQueue<AtBatPitchResults>(10));
                this.playerCount++;
                new Worker(currentPlayer, this.playerMap.get(currentPlayer), this.resultsOutputArray, "Undefined Player").start();
            }
            this.playerMap.get(currentPlayer).put(thisAtBat);
        }
        
        //print report structure, take from abq and send to computation obj which handles all calculations
        System.out.println();
        System.out.printf("Name\t\t\t At Bats   On base   Batting Avg\n");

        int recordCount = 0;
        while(recordCount < this.playerCount) {
            Computation compute = resultsOutputArray.take();
            MessageJNI.writePlayerFinalStatsMsg(compute.getPlayerNumber(), recordCount, playerCount, compute.getName(), compute.getStrikeouts(), compute.getWalks(), compute.getSingles(), compute.getDoubles(), compute.getTriples(), compute.getHomeRuns(), compute.getBattingAvg(), compute.getTotalBattingAvg());
            recordCount++;
        }
    } 
}        