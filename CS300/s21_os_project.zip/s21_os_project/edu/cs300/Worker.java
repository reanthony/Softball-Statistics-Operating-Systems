package edu.cs300;

/* Appended upon by: Eland Anthony
CS300 with Dr. Anderson */

import java.util.concurrent.*;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

class Worker extends Thread{

  ArrayBlockingQueue<AtBatPitchResults> incomingStats;
  ArrayBlockingQueue<Computation> outgoingResults;
  Integer id;
  String name;
  Computation compute;

  public Worker(Integer id,ArrayBlockingQueue<AtBatPitchResults> incomingStats, ArrayBlockingQueue<Computation> outgoingResults, String playerName){
    this.incomingStats=incomingStats;
    this.outgoingResults=outgoingResults; 
    this.id=id;
    this.compute = new Computation();
    this.name=playerName;//put name of player here
  }

  public void run() {

    this.compute.setPLayerNumber(this.id);
    this.compute.setName(this.name);
    this.compute.getCumulativeStats(this.id);

    DebugLog.log("Player Tracker-"+this.id+" ("+this.name+") thread started ...");

    while (true){
      try {

        AtBatPitchResults atBat=(AtBatPitchResults)this.incomingStats.take(); 
        DebugLog.log("Worker-" + this.id + " " + atBat.pitchResults);
        
        //Removes any spaces and special chars
        atBat.pitchResults = atBat.pitchResults.replaceAll("\\s+","");

        //Decode string to add to my vars
        if(atBat.pitchResults.length() >= 1) {
          this.compute.decodePitchResults(atBat.pitchResults);
        }

        //final message from tracker, used to exit out of infinite while loop
        //Game is over - compute, write, and print
        if(atBat.gameOver()) {
          DebugLog.log("Signal'd Game Over");
          
        //Set all results to 0 if no at bats for player            
        if (compute.getAtBats() < 1) {
          this.compute.setNoBatStats();
        }

        //update season stats based on this game
        this.compute.addGameToTotal();

        //Write game stats to player history file <player_id.txt>
        this.compute.writeGame(this.id);

        //print player stats report; must be done from threads
        this.compute.printReport(this.id, this.name);

        //Set total batting avg for player
        this.compute.setTotalBattingAvg(this.compute.getTotalBattingAvg());

        //send game stats back then exit
        this.outgoingResults.put(this.compute);
        return;
        }
        //System.out.println("Game not ending...process pitch results");     
      } catch(InterruptedException e){
      System.err.println(e.getMessage());
      }
    } 
  }

}